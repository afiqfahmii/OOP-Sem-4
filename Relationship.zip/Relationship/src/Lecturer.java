public class Lecturer {
    private String staffnum;

    public Lecturer(String sn) {
        this.staffnum = sn;
    }

    public String getStaffnum() {
        return staffnum;
    }

    public void setStaffnum(String staffnum) {
        this.staffnum = staffnum;
    }
}
